//
// Created by Guillaume on 1/14/19.
//

#include <jni.h>
#include "MovieControllerWrapper.h"
#include "MovieController.h"
#include "handle.h"

/*
 * Class:     com_hub_gui_interview_model_Actor
 * Method:    getAge
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_com_hub_gui_interview_model_Actor_getAge(JNIEnv *env, jobject obj) {
    movies::Actor *p = getHandle<movies::Actor>(env, obj);
    return p->age;
}

/*
 * Class:     com_hub_gui_interview_model_Actor
 * Method:    getName
 * Signature: ()Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_com_hub_gui_interview_model_Actor_getName
        (JNIEnv *env, jobject obj) {
    movies::Actor *p = getHandle<movies::Actor>(env, obj);
    return env->NewStringUTF(p->name.c_str());
}

/*
 * Class:     com_hub_gui_interview_model_Actor
 * Method:    getImageUrl
 * Signature: ()Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_com_hub_gui_interview_model_Actor_getImageUrl
        (JNIEnv *env, jobject obj) {
    movies::Actor *p = getHandle<movies::Actor>(env, obj);
    return env->NewStringUTF(p->imageUrl.c_str());
}

/*
* Class:     com_hub_gui_interview_model_Movie
* Method:    getName
* Signature: ()Ljava/lang/String;
*/
JNIEXPORT jstring JNICALL Java_com_hub_gui_interview_model_Movie_getName
        (JNIEnv *env, jobject obj) {
    movies::Movie *p = getHandle<movies::Movie>(env, obj);
    return env->NewStringUTF(p->name.c_str());
}

/*
 * Class:     com_hub_gui_interview_model_Movie
 * Method:    getLastUpdate
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_com_hub_gui_interview_model_Movie_getLastUpdate
        (JNIEnv *env, jobject obj) {
    movies::Movie *p = getHandle<movies::Movie>(env, obj);
    return p->lastUpdated;
}


/*
 * Class:     com_hub_gui_interview_manager_MovieManager
 * Method:    jniCreateManager
 * Signature: ()J
 */
JNIEXPORT jlong JNICALL Java_com_hub_gui_interview_manager_MovieManager_jniCreateManager
        (JNIEnv *env, jobject obj ) {
    movies::MovieController *controller = new movies::MovieController();
    return (jlong) controller;
}

/*
* Class:     com_hub_gui_interview_manager_MovieManager
* Method:    getMovieList
* Signature: ()[J
*/
JNIEXPORT jlongArray JNICALL Java_com_hub_gui_interview_manager_MovieManager_getMovieList
        (JNIEnv *env, jobject obj) {

    movies::MovieController *controller = getHandle<movies::MovieController>(env, obj);
    std::vector<movies::Movie*> movies = controller->getMovies();

    jlongArray result = env->NewLongArray(movies.size());

    env-> SetLongArrayRegion(result,0,movies.size(),(jlong*) &movies[0]);

    return result;
}

/*
 * Class:     com_hub_gui_interview_manager_MovieManager
 * Method:    getMovieDetails
 * Signature: (Ljava/lang/String;)J
 *
JNIEXPORT jlong JNICALL Java_com_hub_gui_interview_manager_MovieManager_getMovieDetails
        (JNIEnv *, jobject, jstring) {
}*/

