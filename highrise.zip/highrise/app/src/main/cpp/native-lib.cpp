#include <jni.h>
#include <string>
#include <android/log.h>
#include "MovieController.h"

extern "C" JNIEXPORT jstring JNICALL
Java_com_hub_gui_interview_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}

extern "C"
JNIEXPORT jstring JNICALL Java_com_hub_gui_interview_model_Movie_getName
        (JNIEnv *, jobject);

extern "C" JNIEXPORT jobject JNICALL
Java_com_hub_gui_interview_MainActivity_test(JNIEnv *env, jobject object) {

    jclass result = env->FindClass("com/hub/gui/interview/Hello");
    jmethodID constructor = env->GetMethodID(result,"<init>","()V");
    movies::MovieController * controller = new movies::MovieController();
    std::string msg(controller->getMovies().front()->name);
    __android_log_write(ANDROID_LOG_ERROR, "Tag",msg.c_str() );

    return env->NewObject(result,constructor);
}



