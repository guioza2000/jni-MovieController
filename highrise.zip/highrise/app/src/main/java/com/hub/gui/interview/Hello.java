package com.hub.gui.interview;

import android.util.Log;

public class Hello {
    public Hello(){}

    public void print(){
        Log.i("Hello","printing!!");
    }
}
