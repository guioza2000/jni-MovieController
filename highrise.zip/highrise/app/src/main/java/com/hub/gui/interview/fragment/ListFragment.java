package com.hub.gui.interview.fragment;

import android.support.v4.app.Fragment;

public class ListFragment extends Fragment {
}
