package com.hub.gui.interview.manager;

import com.hub.gui.interview.model.JniObject;
import com.hub.gui.interview.model.Movie;
import com.hub.gui.interview.model.MovieDetail;

import java.util.ArrayList;
import java.util.List;

public class MovieManager extends JniObject {

    private static MovieManager sInstance = null;

    public static MovieManager getInstance(){
        if(sInstance == null){
            sInstance = new MovieManager(jniCreateManager());
        }
        return sInstance;
    }

    public MovieManager(long ptr) {
        super(ptr);
    }

    public List<Movie> getMovies(){
        List<Movie> result = new ArrayList<Movie>();
        long[] jniMovies = getMovieList();

        if(jniMovies != null){
            for(long ptr: jniMovies){
                result.add(new Movie(ptr));
            }
        }
        return result;
    }

    private static native long jniCreateManager();
    private native long[] getMovieList();
    private native long getMovieDetails(String movie);
}
