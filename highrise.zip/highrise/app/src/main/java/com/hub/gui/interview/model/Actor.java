package com.hub.gui.interview.model;

public class Actor extends JniObject {

    public Actor(long ptr) {
        super(ptr);
    }

    public native int getAge();
    public native String getName();
    public native String getImageUrl();
}
