package com.hub.gui.interview.model;

public class Movie extends JniObject {

    public Movie(long ptr) {
        super(ptr);
    }

    public native String getName();
    public native int getLastUpdate();
}
