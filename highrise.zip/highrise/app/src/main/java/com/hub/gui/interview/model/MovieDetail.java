package com.hub.gui.interview.model;

import java.util.List;

public class MovieDetail extends JniObject {

    public MovieDetail(long ptr) {
        super(ptr);
    }

    public native String getName();
    public native float getScore();
    public native long[] getActors();
    public native String getDescription();

}
